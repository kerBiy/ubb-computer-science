#include "console.h"
#include "tests.h"

int main() {
    runTests();
    consoleRun();
    return 0;
}