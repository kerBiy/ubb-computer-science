package ubb.map.examenpractic.utils;

public interface Observer {
    void update();
}